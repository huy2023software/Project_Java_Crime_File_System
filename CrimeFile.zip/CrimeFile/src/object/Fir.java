package object;

import java.sql.Date;

public class Fir extends Administrator {
    private String firID;
    private String suspectName;
    private String location;
    private String description;
    private Date dateofOccurence;
    private String evidence;

    public Fir() {
        super();
        this.firID = "";
        this.suspectName = "";
        this.location = "";
        this.description = "";
        this.dateofOccurence = new Date(new java.util.Date().getTime());
        this.evidence = "";
    }

    public Fir(String firID, String suspectName, String location, String description, Date dateofOccurence, String evidence, String adminID, String fullName, int age, char gender, String address, String tel, String password) {
        super(adminID, fullName, age, gender, address, tel, password);
        this.firID = firID;
        this.suspectName = suspectName;
        this.location = location;
        this.description = description;
        this.dateofOccurence = dateofOccurence;
        this.evidence = evidence;
    }

    public String getFirID() {
        return firID;
    }

    public void setFirID(String firID) {
        this.firID = firID;
    }

    public String getSuspectName() {
        return suspectName;
    }

    public void setSuspectName(String suspectName) {
        this.suspectName = suspectName;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Date getDateofOccurence() {
        return dateofOccurence;
    }

    public void setDateofOccurence(Date dateofOccurence) {
        this.dateofOccurence = dateofOccurence;
    }

    public String getEvidence() {
        return evidence;
    }

    public void setEvidence(String evidence) {
        this.evidence = evidence;
    }
}
