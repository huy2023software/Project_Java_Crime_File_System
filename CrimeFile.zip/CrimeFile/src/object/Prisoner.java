package object;

public class Prisoner {

    private String prisonerID;
    private String fullName;
    private int age;
    private char gender;
    private String crimeType;
    private int prisonerTerm;
    private String status;

    public Prisoner() {
         this.prisonerID = "";
        this.fullName = "";
        this.age = 0;
        this.gender = ' ';
        this.crimeType = "";
        this.prisonerTerm = 0;
        this.status = "";
    }

    public Prisoner(String prisonerID, String fullName, int age, char gender, String crimeType, int prisonerTerm, String status) {
        this.prisonerID = prisonerID;
        this.fullName = fullName;
        this.age = age;
        this.gender = gender;
        this.crimeType = crimeType;
        this.prisonerTerm = prisonerTerm;
        this.status = status;
    }

    public String getPrisonerID() {
        return prisonerID;
    }

    public void setPrisonerID(String prisonerID) {
        this.prisonerID = prisonerID;
    }

    public String getfullName() {
        return fullName;
    }

    public void setfullName(String fullName) {
        this.fullName = fullName;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public char getGender() {
        return gender;
    }

    public void setGender(char gender) {
        this.gender = gender;
    }

    public String getCrimeType() {
        return crimeType;
    }

    public void setCrimeType(String crimeType) {
        this.crimeType = crimeType;
    }

    public int getPrisonerTerm() {
        return prisonerTerm;
    }

    public void setPrisonerTerm(int prisonerTerm) {
        this.prisonerTerm = prisonerTerm;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }
}
