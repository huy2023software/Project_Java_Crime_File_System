package object;

public class InvestigatingOfficer {

    private String investigatingOfficerID;
    private String fullName;
    private int age; 
    private char gender;  
    private String  address;
    private String tel;

    public InvestigatingOfficer() {
        this.investigatingOfficerID = "";
        this.fullName = "";
        this.age = 0;
        this.gender = ' ';
        this.address = "";
        this.tel = "";
    }

    public InvestigatingOfficer(String investigatingOfficerID, String fullName, int age, char gender, String address, String tel) {
        this.investigatingOfficerID = investigatingOfficerID;
        this.fullName = fullName;
        this.age = age;
        this.gender = gender;
        this.address = address;
        this.tel = tel;
    }

    public String getInvestigatingOfficerID() {
        return investigatingOfficerID;
    }

    public void setInvestigatingOfficerID(String investigatingOfficerID) {
        this.investigatingOfficerID = investigatingOfficerID;
    }

    public String getfullName() {
        return fullName;
    }

    public void setfullName(String fullName) {
        this.fullName = fullName;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public char getGender() {
        return gender;
    }

    public void setGender(char gender) {
        this.gender = gender;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getTel() {
        return tel;
    }

    public void setTel(String tel) {
        this.tel = tel;
    }
}
