package object;

import java.sql.Date;

public class Victim extends Fir {
    private String victimID;
    private String fullName;
    private String occupation;

    public Victim(String victimID, String occupation, String firID, String suspectName, String location, String description, Date dateofOccurence, String evidence, String adminID, String fullName, int age, char gender, String address, String tel, String password) {
        super(firID, suspectName, location, description, dateofOccurence, evidence, adminID, fullName, age, gender, address, tel, password);
        this.victimID = victimID;
        this.fullName = fullName;
        this.occupation = occupation;
    }

    public String getOccupation() {
        return occupation;
    }

    public void setOccupation(String occupation) {
        this.occupation = occupation;
    }

    public String getVictimID() {
        return victimID;
    }

    public void setVictimID(String victimID) {
        this.victimID = victimID;
    }

    public String getFullName() {
        return fullName;
    }

    public void setFullName(String fullName) {
        this.fullName = fullName;
    }
}