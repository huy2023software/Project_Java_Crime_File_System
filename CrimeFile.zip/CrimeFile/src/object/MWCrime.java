package object;

public class MWCrime {

    private String mwCrimeID;
    private String fullName;
    private int age;
    private char gender;
    private String height;
    private String weight;
    private String identification;
    private String type;
    private byte image;
    private String dangerLevel;
    private String rewardAmount;

    public MWCrime() {
        this.mwCrimeID = "";
        this.fullName = "";
        this.age = 0;
        this.gender = ' ';
        this.height = "";
        this.weight = "";
        this.identification = "";
        this.type = "";
        this.image = Byte.valueOf((byte)0);
        this.dangerLevel = "";
        this.rewardAmount = "";
    }

    public MWCrime(String mwCrimeID, String fullName, int age, char gender, String height, String weight, String identification, String type, byte image, String dangerLevel, String rewardAmount) {
        this.mwCrimeID = mwCrimeID;
        this.fullName = fullName;
        this.age = age;
        this.gender = gender;
        this.height = height;
        this.weight = weight;
        this.identification = identification;
        this.type = type;
        this.image = image;
        this.dangerLevel = dangerLevel;
        this.rewardAmount = rewardAmount;
    }

    public String getMwCrimeID() {
        return mwCrimeID;
    }

    public void setMwCrimeID(String mwCrimeID) {
        this.mwCrimeID = mwCrimeID;
    }

    public String getfullName() {
        return fullName;
    }

    public void setfullName(String fullName) {
        this.fullName = fullName;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public char getGender() {
        return gender;
    }

    public void setGender(char gender) {
        this.gender = gender;
    }

    public String getHeight() {
        return height;
    }

    public void setHeight(String height) {
        this.height = height;
    }

    public String getWeight() {
        return weight;
    }

    public void setWeight(String weight) {
        this.weight = weight;
    }

    public String getIdentification() {
        return identification;
    }

    public void setIdentification(String identification) {
        this.identification = identification;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public byte getImage() {
        return image;
    }

    public void setImage(byte image) {
        this.image = image;
    }

    public String getDangerLevel() {
        return dangerLevel;
    }

    public void setDangerLevel(String dangerLevel) {
        this.dangerLevel = dangerLevel;
    }

    public String getRewardAmount() {
        return rewardAmount;
    }

    public void setRewardAmount(String rewardAmount) {
        this.rewardAmount = rewardAmount;
    }
}
