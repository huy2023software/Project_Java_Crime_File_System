package object;

import java.sql.Date;

public class Case extends Fir{

    private String caseID;
    private String caseName;
    private String status;

    public Case() {
        super();
        this.caseID = "";
        this.caseName = "";
        this.status = "";
    }

    public Case(String caseID, String caseName, String status, String firID, String suspectName, String location, String description, Date dateofOccurence, String evidence, String adminID, String fullName, int age, char gender, String address, String tel, String password) {
        super();
        this.caseID = caseID;
        this.caseName = caseName;
        this.status = status;
    }

    public String getCaseID() {
        return caseID;
    }

    public void setCaseID(String caseID) {
        this.caseID = caseID;
    }

    public String getCaseName() {
        return caseName;
    }

    public void setCaseName(String caseName) {
        this.caseName = caseName;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }
}
