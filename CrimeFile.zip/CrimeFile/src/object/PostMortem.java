package object;

import java.sql.Date;

public class PostMortem extends Administrator {

    private String postMortemID;
    private String location;
    private Date dateofDeath;
    private String causeofDeath;
    private String evidence;
    private String doctorName;

    public PostMortem() {
        super();
        this.postMortemID = "";
        this.location = "";
        this.dateofDeath = new Date(new java.util.Date().getTime());
        this.causeofDeath = "";
        this.evidence = "";
        this.doctorName = "";
    }

    public PostMortem(String postMortemID, String location, Date dateofDeath, String causeofDeath, String evidence, String doctorName, String adminID, String fullName, int age, char gender, String address, String tel, String password) {
        super(adminID, fullName, age, gender, address, tel, password);
        this.postMortemID = postMortemID;
        this.location = location;
        this.dateofDeath = dateofDeath;
        this.causeofDeath = causeofDeath;
        this.evidence = evidence;
        this.doctorName = doctorName;
    }

    public String getpostMortemID() {
        return postMortemID;
    }

    public void setpostMortemID(String postMortemID) {
        this.postMortemID = postMortemID;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public Date getDateofDeath() {
        return dateofDeath;
    }

    public void setDateofDeath(Date dateofDeath) {
        this.dateofDeath = dateofDeath;
    }

    public String getCauseofDeath() {
        return causeofDeath;
    }

    public void setCauseofDeath(String causeofDeath) {
        this.causeofDeath = causeofDeath;
    }

    public String getEvidence() {
        return evidence;
    }

    public void setEvidence(String evidence) {
        this.evidence = evidence;
    }

    public String getDoctorName() {
        return doctorName;
    }

    public void setDoctorName(String doctorName) {
        this.doctorName = doctorName;
    }
}