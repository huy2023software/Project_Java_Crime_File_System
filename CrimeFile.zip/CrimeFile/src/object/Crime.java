package object;

public class Crime {

    private String crimeID;
    private String fullName;
    private int age;
    private char gender;
    private String occupation;
    private String type;

    public Crime() {
        this.crimeID = "";
        this.fullName = "";
        this.age = 0;
        this.gender = ' ';
        this.occupation = "";
        this.type = "";
    }

    public Crime(String crimeID, String fullName, int age, char gender, String occupation, String type) {
        this.crimeID = crimeID;
        this.fullName = fullName;
        this.age = age;
        this.gender = gender;
        this.occupation = occupation;
        this.type = type;
    }

    public String getCrimeID() {
        return crimeID;
    }

    public void setCrimeID(String crimeID) {
        this.crimeID = crimeID;
    }

    public String getfullName() {
        return fullName;
    }

    public void setfullName(String fullName) {
        this.fullName = fullName;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public char getGender() {
        return gender;
    }

    public void setGender(char gender) {
        this.gender = gender;
    }

    public String getOccupation() {
        return occupation;
    }

    public void setOccupation(String occupation) {
        this.occupation = occupation;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }
}
