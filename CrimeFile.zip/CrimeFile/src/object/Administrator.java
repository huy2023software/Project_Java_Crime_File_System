package object;

public class Administrator {
    String adminID;
    private String fullName;
    private int age;
    private char gender;
    private String address;
    private String tel;
    private String password;

    public Administrator() {
        this.adminID = "";
        this.fullName = "";
        this.age = 0;
        this.gender = ' ';
        this.address = "";
        this.tel = "";
        this.password = "";
    }

    public Administrator(String adminID, String fullName, int age, char gender, String address, String tel, String password) {
        this.adminID = adminID;
        this.fullName = fullName;
        this.age = age;
        this.gender = gender;
        this.address = address;
        this.tel = tel;
        this.password = password;
    }

    public String getAdminID() {
        return adminID;
    }

    public void setAdminID(String adminID) {
        this.adminID = adminID;
    }

    public String getfullName() {
        return fullName;
    }

    public void setfullName(String fullName) {
        this.fullName = fullName;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public char getGender() {
        return gender;
    }

    public void setGender(char gender) {
        this.gender = gender;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getTel() {
        return tel;
    }

    public void setTel(String tel) {
        this.tel = tel;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }
}
