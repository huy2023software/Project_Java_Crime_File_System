package object;

import java.sql.Date;

public class Complaint {

    private String complaintID;
    private String suspectName;
    private String location;
    private Date complaintDate;
    private String complaintType;
    private String description;
    private String status;
    private String username;

    public Complaint() {
        this.complaintID = "";
        this.suspectName = "";
        this.location = "";
        this.complaintDate = new Date(new java.util.Date().getTime());
        this.complaintType = "";
        this.description = "";
        this.status = "";
        this.username = "";
    
    }

    public Complaint(String complaintID, String suspectName, String location, Date complaintDate, String complaintType, String description, String status, String username) {
        this.complaintID = complaintID;
        this.suspectName = suspectName;
        this.location = location;
        this.complaintDate = complaintDate;
        this.complaintType = complaintType;
        this.description = description;
        this.status = status;
        this.username = username;
    }

    public String getComplaintID() {
        return complaintID;
    }

    public void setComplaintID(String complaintID) {
        this.complaintID = complaintID;
    }

    public String getSuspectName() {
        return suspectName;
    }

    public void setSuspectName(String suspectName) {
        this.suspectName = suspectName;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public Date getComplaintDate() {
        return complaintDate;
    }

    public void setComplaintDate(Date complaintDate) {
        this.complaintDate = complaintDate;
    }

    public String getComplaintType() {
        return complaintType;
    }

    public void setComplaintType(String complaintType) {
        this.complaintType = complaintType;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }
}
    