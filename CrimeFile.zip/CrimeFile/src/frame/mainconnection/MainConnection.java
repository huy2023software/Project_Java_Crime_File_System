
package frame.mainconnection;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class MainConnection {
    public static Connection getConnection(){
        Connection connCrimeFile = null;
        
        try {
             String username = "sa";
            String password = "sa";
            String url = "jdbc:sqlserver://localhost\\MSSQLSERVER:1433;databaseName=CrimeFile;entrypt=true;trustServerCertificate=true;";
            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
           connCrimeFile =  DriverManager.getConnection(url, username, password);
        } catch (ClassNotFoundException | SQLException e) {
            System.out.println("Error main connection"+ e);
        }
        return connCrimeFile;
    }
}
